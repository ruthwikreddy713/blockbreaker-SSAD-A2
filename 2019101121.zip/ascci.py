from colorama import *
import numpy as np
init()
print(Fore.MAGENTA+u"$$$$")
print(Fore.MAGENTA+u"|  |")
print(Fore.MAGENTA+u'$$$$')
 ___ _   _  ___ ___ ___  ___ ___ 
/ __| | | |/ __/ __/ _ \/ __/ __|
\__ \ |_| | (_| (_|  __/\__ \__ \
|___/\__,_|\___\___\___||___/___/
                                 